#ifndef _HELLOPRINT_H_
#define _HELLOPRINT_H_

// Protótipo da função
void printHello( void );

#endif // _HELLOPRINT_H_