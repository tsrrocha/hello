/*==================================================
                    HELLO
  --------------------------------------------------


  ==================================================*/
  
  #include <stdio.h>
  #include <stdlib.h>
  #include "helloprint.h"
  #include "hello.h"

  int main () {
      printHello();
      return (0);
  }