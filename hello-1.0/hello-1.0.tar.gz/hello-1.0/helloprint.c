#include <stdio.h>
#include "helloprint.h"

void printHello( void ) {
    fprintf(stdout, "Hello - DEBUG - Ola, mundo legal!!!");
}